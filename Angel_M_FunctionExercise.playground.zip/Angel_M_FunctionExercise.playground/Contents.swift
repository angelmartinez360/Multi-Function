import UIKit

var str = "Hello, playground"

let mult = {
    (num1: Int, num2: Int) -> Int in
return num1 * num2
}
let numbers = mult(10,50)
print (numbers)
